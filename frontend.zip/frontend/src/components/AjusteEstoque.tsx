export default function AjusteEstoque() {
  return (
    <div className="p-4 border rounded shadow bg-white">
      <h3 className="text-xl font-semibold mb-4">Ajustes Manuais de Estoque</h3>
      <p>Em breve: tela de ajuste manual.</p>
    </div>
  );
}
