// types/ComandaResumoDTO.ts
export interface ComandaResumoDTO {
  id: number;
  dataFechamento: string;
  valorTotal: number;
  nomeCliente: string;
  observacoes: string;
}
